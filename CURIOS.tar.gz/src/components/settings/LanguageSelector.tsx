import { useState, useRef, useEffect } from 'react';
import { useLanguage } from '../../contexts/LanguageContext.tsx';
import { languages, Language } from '../../types/language.ts';

export default function LanguageSelector(): JSX.Element {
  
  const { currentLanguage, setLanguage } = useLanguage()
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="bg-[#222222] w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#2a2a2a] transition-colors overflow-hidden"
          title={currentLanguage.name}
        >
        <img src={currentLanguage.flag} className="w-[28px] h-[28px] rounded-full object-cover object-center border border-[#666666] m-[0.1rem]" alt={currentLanguage.name}/>
        </button>

        {isOpen && (
          <div className="absolute right-0 mt-2 p-2 bg-[#222222] rounded-xl border border-gray-800 shadow-lg flex flex-wrap gap-2 max-w-[280px] w-max z-50">
            {languages.map((lang: Language) => (
              <button
                type="button"
                key={lang.code}
                onClick={() => {
                  setLanguage(lang);
                  setIsOpen(false);
                }}
                className={`w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#333333] transition-all transform hover:scale-110 ${
                  currentLanguage.code === lang.code ? 'bg-[#333333] scale-110' : ''
                }`}
                style={{ margin: '0.2rem' }}
                title={lang.name}
              >
                  <img src={lang.flag} className="w-[28px] h-[28px] rounded-full object-cover object-center border border-[#666666] m-[0.1rem]" alt={lang.name}/>
              </button>
            ))}
          </div>
        )}
      </div>
    );
}